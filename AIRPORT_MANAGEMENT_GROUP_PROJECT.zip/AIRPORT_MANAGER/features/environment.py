def before_all(context):
    print("=== Започва изпълнение на тестовете ===")

def after_all(context):
    print("=== Тестовете приключиха ===")